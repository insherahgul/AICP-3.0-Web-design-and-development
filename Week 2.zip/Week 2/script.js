    window.addEventListener('load', () => {
    const addTaskBtn = document.querySelector("#add-task-btn");
    const showTasksBtn = document.querySelector("#show-tasks-btn");
    const showDeletedBtn = document.querySelector("#show-deleted-btn");
    const newTaskForm = document.querySelector("#new-task-form");
    const taskList = document.querySelector("#tasks");
    const main = document.querySelector("main");
    const tasks = []; // Array to store tasks
    const deletedTasks = []; // Array to store deleted tasks

    addTaskBtn.addEventListener('click', () => {
        newTaskForm.style.display = "block";
        main.style.display = "none";
    });

    showTasksBtn.addEventListener('click', () => {
        renderTaskList(tasks);
        newTaskForm.style.display = "none";
        main.style.display = "block";
    });

    showDeletedBtn.addEventListener('click', () => {
        renderTaskList(deletedTasks);
    });

    const renderTaskList = (taskArray) => {
        taskList.innerHTML = ''; // Clear existing task list
        taskArray.forEach(task => {
            const taskEl = createTaskElement(task.title, task.description);
            taskList.appendChild(taskEl);
        });
    };

    const createTaskElement = (title, description) => {
        const taskEl = document.createElement('div');
        taskEl.classList.add('task');

        const taskTitleEl = document.createElement('div');
        taskTitleEl.classList.add('title');
        taskTitleEl.textContent = title;

        const taskDescriptionEl = document.createElement('div');
        taskDescriptionEl.classList.add('description');
        taskDescriptionEl.textContent = description;

        const taskActionsEl = document.createElement('div');
        taskActionsEl.classList.add('actions');

        const taskEditEl = document.createElement('button');
        taskEditEl.textContent = 'Edit';

        const taskDeleteEl = document.createElement('button');
        taskDeleteEl.textContent = 'Delete';

        taskActionsEl.appendChild(taskEditEl);
        taskActionsEl.appendChild(taskDeleteEl);

        taskEl.appendChild(taskTitleEl);
        taskEl.appendChild(taskDescriptionEl);
        taskEl.appendChild(taskActionsEl);

        taskEditEl.addEventListener('click', () => {
            const isEditable = taskTitleEl.contentEditable === 'true';

            if (isEditable) {
                taskTitleEl.contentEditable = 'false';
                taskDescriptionEl.contentEditable = 'false';
                taskEditEl.textContent = 'Edit';
            } else {
                taskTitleEl.contentEditable = 'true';
                taskDescriptionEl.contentEditable = 'true';
                taskEditEl.textContent = 'Save';
            }
        });

        taskDeleteEl.addEventListener('click', () => {
            const index = tasks.findIndex(task => task.title === title && task.description === description);
            if (index !== -1) {
                deletedTasks.push(tasks.splice(index, 1)[0]);
                renderTaskList(tasks);
            }
        });

        return taskEl;
    };

    const form = document.querySelector("#new-task-form");
    const inputTitle = document.querySelector("#new-task-input");
    const inputDescription = document.querySelector("#new-task-description");

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const taskTitle = inputTitle.value;
        const taskDescription = inputDescription.value;

        if (!taskTitle) {
            alert("Please enter a task title");
            return;
        }

        tasks.push({ title: taskTitle, description: taskDescription });
        renderTaskList(tasks);

        inputTitle.value = '';
        inputDescription.value = '';
    });
});
