document.getElementById("registrationForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    // Get form data
    let formData = new FormData(this);

    // Display form data
    let displayDiv = document.getElementById("displayData");
    displayDiv.innerHTML = "<h2>Submitted Data:</h2>";
    for (let pair of formData.entries()) {
        displayDiv.innerHTML += `<p><strong>${pair[0]}:</strong> ${pair[1]}</p>`;
    }

    // Clear form
    this.reset();
});